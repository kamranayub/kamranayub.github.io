# History

## v1.0.2 January 16, 2015
- Fixed build
- Added test for text files

## v1.0.1 January 16, 2015
- Cleaned up thanks to [Shunnosuke Watanabe](https://github.com/shinnn) for [pull request #2](https://github.com/bevry/istextorbinary/pull/2)

## v1.0.0 October 25, 2013
- Initial release extracted from [balupton/bal-util](https://github.com/balupton/bal-util/blob/6501d51bc0244fce3781fc0150136f7493099237/src/lib/paths.coffee#L100-L201)

