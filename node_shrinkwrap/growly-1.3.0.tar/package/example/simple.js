var growly = require('../lib/growly.js');

growly.notify('Hello, world!');
