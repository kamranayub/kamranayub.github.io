1.1.0 / 2012-12-12 
==================

- Default registration work lazily, and is performed on the first call to `Growly.notify()`.
- Added callback to `Growly.register()`.
