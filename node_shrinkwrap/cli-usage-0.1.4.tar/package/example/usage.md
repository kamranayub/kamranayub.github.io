# CLI Usage
Some sort of description here..

```
$ how --to="use" | grep it
```