
require('./foreach');
require('./isArguments');

require('./shim');

