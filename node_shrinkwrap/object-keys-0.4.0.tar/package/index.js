module.exports = Object.keys || require('./shim');

