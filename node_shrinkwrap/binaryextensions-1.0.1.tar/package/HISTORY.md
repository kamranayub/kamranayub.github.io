# History

## v1.0.1 2016 May 2
- Updated meta files

## v1.0.0 December 10, 2013
- Extracted from [bal-util](https://github.com/balupton/bal-util/blob/6501d51bc0244fce3781fc0150136f7493099237/src/lib/paths.coffee#L81-L96)
