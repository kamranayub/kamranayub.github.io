'use strict';

module.exports = require('./lib/gulp-copy');