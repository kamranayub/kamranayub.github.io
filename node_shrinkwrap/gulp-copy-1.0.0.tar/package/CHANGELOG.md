
## 1.0.0
* Require node v4
* Require gulp 3.9.x
* Automated tests

## 0.0.2 Streams release
* use nodejs streams to write files (instead of cp command)
* fix callback issues (which probably will fix the too many open files bug)

## 0.0.1 Initial release
* initial code