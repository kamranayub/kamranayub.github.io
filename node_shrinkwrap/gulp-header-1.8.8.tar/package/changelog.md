# Changelog

Will welcome if anyone wants to backfill prior changelogs.

## 1.8.8 - 2016-08-10

* #47 Support for gulp-data
* #46 Fix undefined template local "filename"
* #46 Document `file` and `filename` locals.
* #45 Started CHANGELOG.md
