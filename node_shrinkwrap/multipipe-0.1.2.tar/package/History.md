
0.1.1 / 2014-06-01
==================

 * update duplexer2 dep

0.1.0 / 2014-05-24
==================

 * add optional callback

0.0.2 / 2014-02-20 
==================

 * fix infinite loop

0.0.1 / 2014-01-15
==================

* fix error bubbling

0.0.0 / 2014-01-13
==================

* initial release
