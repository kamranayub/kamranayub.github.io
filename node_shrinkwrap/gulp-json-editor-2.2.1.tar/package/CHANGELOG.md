## 2.2.1

Features:

  - keep indentation if no option is specified
