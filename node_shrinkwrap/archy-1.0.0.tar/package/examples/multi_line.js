var archy = require('../');

var s = archy({
  label : 'beep\none\ntwo',
  nodes : [
    'ity',
    {
      label : 'boop',
      nodes : [
        {
          label : 'o_O\nwheee',
          nodes : [
            {
              label : 'oh',
              nodes : [ 'hello', 'puny\nmeat' ]
            },
            'creature'
          ]
        },
        'party\ntime!'
      ]
    }
  ]
});
console.log(s);
